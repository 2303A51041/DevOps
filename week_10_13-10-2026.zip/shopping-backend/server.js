
const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Sample product data
let products = [
  {
    id: 1,
    name: "Laptop",
    category: "Electronics",
    price: 60000
  },
  {
    id: 2,
    name: "Headphones",
    category: "Electronics",
    price: 2000
  },
  {
    id: 3,
    name: "Backpack",
    category: "Accessories",
    price: 1500
  }
];

// Validate product information
function validateProduct(data) {
  const { name, category, price } = data;

  if (
    typeof name !== "string" ||
    !name.trim() ||
    typeof category !== "string" ||
    !category.trim() ||
    price === undefined ||
    price === null ||
    !Number.isFinite(Number(price)) ||
    Number(price) < 0
  ) {
    return false;
  }

  return true;
}

// GET: Retrieve all products
app.get("/api/products", (req, res) => {
  res.status(200).json(products);
});

// GET: Retrieve a product by ID
app.get("/api/products/:id", (req, res) => {
  const id = Number(req.params.id);
  const product = products.find((item) => item.id === id);

  if (!product) {
    return res.status(404).json({
      message: "Product not found"
    });
  }

  res.status(200).json(product);
});

// POST: Add a new product
app.post("/api/products", (req, res) => {
  if (!validateProduct(req.body)) {
    return res.status(400).json({
      message: "Please provide a valid name, category, and price."
    });
  }

  const newProduct = {
    id: products.length
      ? Math.max(...products.map((item) => item.id)) + 1
      : 1,
    name: req.body.name.trim(),
    category: req.body.category.trim(),
    price: Number(req.body.price)
  };

  products.push(newProduct);

  res.status(201).json({
    message: "Product added successfully",
    product: newProduct
  });
});

// PUT: Update an existing product
app.put("/api/products/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = products.findIndex((item) => item.id === id);

  if (index === -1) {
    return res.status(404).json({
      message: "Product not found"
    });
  }

  if (!validateProduct(req.body)) {
    return res.status(400).json({
      message: "Please provide valid product details."
    });
  }

  products[index] = {
    id,
    name: req.body.name.trim(),
    category: req.body.category.trim(),
    price: Number(req.body.price)
  };

  res.status(200).json({
    message: "Product updated successfully",
    product: products[index]
  });
});

// DELETE: Remove a product
app.delete("/api/products/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = products.findIndex((item) => item.id === id);

  if (index === -1) {
    return res.status(404).json({
      message: "Product not found"
    });
  }

  const deletedProduct = products.splice(index, 1)[0];

  res.status(200).json({
    message: "Product deleted successfully",
    product: deletedProduct
  });
});

// Handle unknown API routes
app.use("/api", (req, res) => {
  res.status(404).json({
    message: "API endpoint not found"
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Backend server running at http://localhost:${PORT}`);
});
