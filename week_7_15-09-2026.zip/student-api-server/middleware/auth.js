const jwt = require("jsonwebtoken");


const SECRET_KEY = "student_secret_key";


function authMiddleware(req, res, next) {


    const header = req.headers.authorization;



    if (!header) {

        return res.status(401).json({

            message: "JWT token missing"

        });

    }



    const token =
        header.split(" ")[1];



    try {

        const decoded =
            jwt.verify(
                token,
                SECRET_KEY
            );


        req.user = decoded;


        next();


    }

    catch (error) {


        return res.status(401).json({

            message: "Invalid or expired token"

        });


    }


}


module.exports = authMiddleware;