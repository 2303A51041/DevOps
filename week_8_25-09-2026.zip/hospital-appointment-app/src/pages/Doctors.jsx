import { Link } from "react-router-dom"

function Doctors() {
  const doctors = [
    {
      id: 1,
      name: "Dr. Anil Kumar",
      specialization: "Cardiologist"
    },
    {
      id: 2,
      name: "Dr. Priya Sharma",
      specialization: "Dermatologist"
    },
    {
      id: 3,
      name: "Dr. Rahul Verma",
      specialization: "Neurologist"
    }
  ]

  return (
    <div>
      <h1>Available Doctors</h1>

      {doctors.map((doctor) => (
        <div key={doctor.id}>
          <h2>{doctor.name}</h2>
          <p>{doctor.specialization}</p>

          <Link to={`/doctors/${doctor.id}`}>
            View Details
          </Link>
        </div>
      ))}
    </div>
  )
}

export default Doctors