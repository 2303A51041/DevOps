function Profile() {
  return (
    <div>
      <h1>Patient Profile</h1>
      <p>Name: Siddarth</p>
      <p>Patient ID: P1001</p>
      <p>Email: patient@example.com</p>
    </div>
  )
}

export default Profile