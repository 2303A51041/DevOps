function Home() {
  return (
    <div>
      <h1>Welcome to City Care Hospital</h1>
      <p>Quality healthcare with trusted doctors.</p>
      <p>Book appointments easily and manage your profile.</p>
    </div>
  )
}

export default Home