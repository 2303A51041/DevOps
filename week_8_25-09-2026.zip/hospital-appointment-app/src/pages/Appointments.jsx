function Appointments() {
  return (
    <div>
      <h1>Appointments</h1>
      <p>No appointments booked yet.</p>
    </div>
  )
}

export default Appointments
