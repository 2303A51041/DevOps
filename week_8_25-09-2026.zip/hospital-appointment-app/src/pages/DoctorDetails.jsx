import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"

const doctors = [
  {
    id: 1,
    name: "Dr. Anil Kumar",
    specialization: "Cardiologist",
    experience: "12 years",
    fee: "₹800"
  },
  {
    id: 2,
    name: "Dr. Priya Sharma",
    specialization: "Dermatologist",
    experience: "9 years",
    fee: "₹600"
  },
  {
    id: 3,
    name: "Dr. Rahul Verma",
    specialization: "Neurologist",
    experience: "15 years",
    fee: "₹1000"
  }
]

function DoctorDetails() {
  const { id } = useParams()

  const [doctor, setDoctor] = useState(null)
  const [loading, setLoading] = useState(true)
  const [appointmentStatus, setAppointmentStatus] = useState("Not Booked")

  useEffect(() => {
    setLoading(true)
    setAppointmentStatus("Not Booked")

    const timer = setTimeout(() => {
      const selectedDoctor = doctors.find(
        (doctor) => doctor.id === Number(id)
      )

      setDoctor(selectedDoctor || null)
      setLoading(false)
    }, 500)

    return () => {
      clearTimeout(timer)
    }
  }, [id])

  const bookAppointment = () => {
    setAppointmentStatus("Appointment Booked Successfully")
  }

  if (loading) {
    return <h2>Loading doctor information...</h2>
  }

  if (!doctor) {
    return <h2>Doctor Not Found</h2>
  }

  return (
    <div>
      <h1>Doctor Details</h1>

      <h2>{doctor.name}</h2>
      <p>Specialization: {doctor.specialization}</p>
      <p>Experience: {doctor.experience}</p>
      <p>Consultation Fee: {doctor.fee}</p>

      <p>Status: {appointmentStatus}</p>

      <button onClick={bookAppointment}>
        Book Appointment
      </button>
    </div>
  )
}

export default DoctorDetails