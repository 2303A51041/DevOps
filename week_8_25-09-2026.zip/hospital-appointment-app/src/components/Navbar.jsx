import { Link } from "react-router-dom"

function Navbar() {
  return (
    <nav>
      <h2>City Care Hospital</h2>

      <Link to="/">Home</Link>
      <Link to="/doctors">Doctors</Link>
      <Link to="/appointments">Appointments</Link>
      <Link to="/profile">Profile</Link>
    </nav>
  )
}

export default Navbar