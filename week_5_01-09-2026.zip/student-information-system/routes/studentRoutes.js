const express = require("express");
const Student = require("../models/Student");

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const student = await Student.create(req.body);

    res.status(201).json({
      message: "Student added successfully",
      student
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({
        message: "Student ID or email already exists"
      });
    }

    res.status(400).json({
      message: "Failed to add student",
      error: error.message
    });
  }
});

router.get("/", async (req, res) => {
  try {
    const students = await Student.find();

    res.json(students);
  } catch (error) {
    res.status(500).json({
      message: "Failed to retrieve students",
      error: error.message
    });
  }
});

router.get("/department/:department", async (req, res) => {
  try {
    const students = await Student.find({
      department: req.params.department
    });

    res.json(students);
  } catch (error) {
    res.status(500).json({
      message: "Failed to search students",
      error: error.message
    });
  }
});

router.get("/sort/cgpa", async (req, res) => {
  try {
    const students = await Student.find().sort({ cgpa: -1 });

    res.json(students);
  } catch (error) {
    res.status(500).json({
      message: "Failed to sort students",
      error: error.message
    });
  }
});

router.get("/count", async (req, res) => {
  try {
    const count = await Student.countDocuments();

    res.json({
      totalStudents: count
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to count students",
      error: error.message
    });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);

    if (!student) {
      return res.status(404).json({
        message: "Student not found"
      });
    }

    res.json(student);
  } catch (error) {
    res.status(400).json({
      message: "Invalid student ID"
    });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const student = await Student.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    );

    if (!student) {
      return res.status(404).json({
        message: "Student not found"
      });
    }

    res.json({
      message: "Student updated successfully",
      student
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({
        message: "Student ID or email already exists"
      });
    }

    res.status(400).json({
      message: "Failed to update student",
      error: error.message
    });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const student = await Student.findByIdAndDelete(req.params.id);

    if (!student) {
      return res.status(404).json({
        message: "Student not found"
      });
    }

    res.json({
      message: "Student deleted successfully"
    });
  } catch (error) {
    res.status(400).json({
      message: "Invalid student ID"
    });
  }
});

module.exports = router;