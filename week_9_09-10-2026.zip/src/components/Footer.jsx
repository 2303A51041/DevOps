function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 BookVerse. All rights reserved.</p>
      <p>Find your next great read with us.</p>
    </footer>
  );
}

export default Footer;