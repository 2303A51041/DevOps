import { Link } from "react-router-dom";

function BookCard({ book, onAddToCart }) {
  return (
    <div className="book-card">
      <img src={book.image} alt={book.title} />

      <div className="book-info">
        <h3>{book.title}</h3>
        <p>By {book.author}</p>
        <p className="book-category">{book.category}</p>
        <p className="book-rating">⭐ {book.rating}</p>
        <h4>₹{book.price}</h4>

        <div className="book-actions">
          <Link to={`/books/${book.id}`} className="details-btn">
            View Details
          </Link>

          <button onClick={() => onAddToCart(book)}>
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}

export default BookCard;