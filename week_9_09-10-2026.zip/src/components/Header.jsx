import { Link } from "react-router-dom";

function Header() {
  return (
    <header className="header">
      <Link to="/" className="logo">
        📚 BookVerse
      </Link>

      <div className="header-text">
        <h1>Online Book Store</h1>
        <p>Discover your next favourite book</p>
      </div>

      <Link to="/cart" className="header-cart">
        🛒 Cart
      </Link>
    </header>
  );
}

export default Header;