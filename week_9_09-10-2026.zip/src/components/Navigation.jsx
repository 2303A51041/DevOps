import { NavLink } from "react-router-dom";

function Navigation() {
  return (
    <nav className="navigation">
      <NavLink to="/">Home</NavLink>
      <NavLink to="/books">Books</NavLink>
      <NavLink to="/categories">Categories</NavLink>
      <NavLink to="/cart">Cart</NavLink>
      <NavLink to="/profile">Profile</NavLink>
    </nav>
  );
}

export default Navigation;