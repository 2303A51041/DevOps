function Cart({ cart, onRemoveFromCart }) {
  const total = cart.reduce((sum, book) => sum + book.price, 0);

  return (
    <div className="page-container">
      <h2>Shopping Cart</h2>

      {cart.length === 0 ? (
        <div className="empty-message">
          <h3>Your cart is empty!</h3>
          <p>Explore our collection and add your favourite books.</p>
        </div>
      ) : (
        <>
          <div className="cart-list">
            {cart.map((book, index) => (
              <div className="cart-item" key={`${book.id}-${index}`}>
                <img src={book.image} alt={book.title} />

                <div className="cart-item-info">
                  <h3>{book.title}</h3>
                  <p>Author: {book.author}</p>
                  <p>Price: ₹{book.price}</p>
                </div>

                <button
                  className="remove-btn"
                  onClick={() => onRemoveFromCart(index)}
                >
                  Remove
                </button>
              </div>
            ))}
          </div>

          <div className="cart-total">
            <h3>Total Amount: ₹{total}</h3>
            <p>{cart.length} item(s) in your cart</p>
          </div>
        </>
      )}
    </div>
  );
}

export default Cart;