import { Link } from "react-router-dom";

function Profile({ recentlyViewed }) {
  return (
    <div className="page-container">
      <h2>My Profile</h2>

      <div className="profile-card">
        <div className="profile-avatar">👤</div>

        <h3>Book Lover</h3>
        <p>Email: reader@example.com</p>
        <p>Membership: Standard Reader</p>
      </div>

      <section className="content-section">
        <h2>Recently Viewed Books</h2>

        {recentlyViewed.length === 0 ? (
          <p className="empty-message">
            You haven't viewed any books yet.
          </p>
        ) : (
          <div className="recent-list">
            {recentlyViewed.map((book) => (
              <div className="recent-item" key={book.id}>
                <span>{book.title}</span>

                <Link to={`/books/${book.id}`}>
                  View Details
                </Link>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

export default Profile;