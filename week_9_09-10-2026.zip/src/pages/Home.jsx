import { Link } from "react-router-dom";
import BookCard from "../components/BookCard";
import books from "../data/books";

function Home({ onAddToCart, recentlyViewed }) {
  const featuredBooks = books.slice(0, 3);

  return (
    <div className="home-page">
      <section className="hero">
        <div>
          <h2>Welcome to BookVerse</h2>
          <p>
            Explore programming, technology, and other fascinating books.
            Find your next favourite read today.
          </p>
          <Link to="/books" className="explore-btn">
            Explore Books
          </Link>
        </div>
      </section>

      <section className="content-section">
        <h2>Featured Books</h2>

        <div className="book-grid">
          {featuredBooks.map((book) => (
            <BookCard
              key={book.id}
              book={book}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      </section>

      {recentlyViewed.length > 0 && (
        <section className="content-section">
          <h2>Recently Viewed Books</h2>

          <div className="book-grid">
            {recentlyViewed.map((book) => (
              <BookCard
                key={book.id}
                book={book}
                onAddToCart={onAddToCart}
              />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

export default Home;