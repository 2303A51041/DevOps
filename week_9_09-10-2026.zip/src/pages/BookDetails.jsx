import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import books from "../data/books";

function BookDetails({ onAddToCart }) {
  const { bookId } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;

    setLoading(true);
    setError("");
    setBook(null);

    const timer = setTimeout(() => {
      if (!active) return;

      const foundBook = books.find((item) => item.id === bookId);

      if (foundBook) {
        setBook(foundBook);
      } else {
        setError("Sorry, the requested book was not found.");
      }

      setLoading(false);
    }, 500);

    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [bookId]);

  if (loading) {
    return <div className="status-message">Loading book details...</div>;
  }

  if (error) {
    return (
      <div className="status-message">
        <h2>Book Not Found</h2>
        <p>{error}</p>
        <Link to="/books" className="details-btn">
          Back to Books
        </Link>
      </div>
    );
  }

  const currentIndex = books.findIndex((item) => item.id === bookId);
  const previousBook = books[currentIndex - 1];
  const nextBook = books[currentIndex + 1];

  return (
    <div className="book-details-page">
      <div className="details-card">
        <img src={book.image} alt={book.title} />

        <div className="details-content">
          <h2>{book.title}</h2>
          <p><strong>Book ID:</strong> {book.id}</p>
          <p><strong>Author:</strong> {book.author}</p>
          <p><strong>Category:</strong> {book.category}</p>
          <p><strong>Rating:</strong> ⭐ {book.rating}/5</p>
          <h3>Price: ₹{book.price}</h3>
          <p>{book.description}</p>

          <button onClick={() => onAddToCart(book)}>
            Add to Cart
          </button>

          <button
            className="secondary-btn"
            onClick={() => navigate("/books")}
          >
            Back to Books
          </button>
        </div>
      </div>

      <div className="book-navigation">
        <button
          disabled={!previousBook}
          onClick={() => navigate(`/books/${previousBook.id}`)}
        >
          Previous Book
        </button>

        <button
          disabled={!nextBook}
          onClick={() => navigate(`/books/${nextBook.id}`)}
        >
          Next Book
        </button>
      </div>
    </div>
  );
}

export default BookDetails;