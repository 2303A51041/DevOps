import { useNavigate } from "react-router-dom";
import books from "../data/books";

function Categories() {
  const navigate = useNavigate();
  const categories = [...new Set(books.map((book) => book.category))];

  function openCategory(category) {
    navigate(`/books?category=${encodeURIComponent(category)}`);
  }

  return (
    <div className="page-container">
      <h2>Browse Categories</h2>

      <div className="category-grid">
        {categories.map((category) => {
          const count = books.filter(
            (book) => book.category === category
          ).length;

          return (
            <div className="category-card" key={category}>
              <h3>{category}</h3>
              <p>{count} book(s)</p>
              <button onClick={() => openCategory(category)}>
                Explore Category
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default Categories;