import { useState } from "react";
import BookCard from "../components/BookCard";
import books from "../data/books";

function BookList({ onAddToCart }) {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");

  const categories = [
    "All",
    ...new Set(books.map((book) => book.category))
  ];

  const filteredBooks = books.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(search.toLowerCase()) ||
      book.author.toLowerCase().includes(search.toLowerCase());

    const matchesCategory =
      category === "All" || book.category === category;

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="page-container">
      <h2>Explore Our Books</h2>

      <div className="book-filters">
        <input
          type="text"
          placeholder="Search by book title or author..."
          value={search}
          onChange={(event) => setSearch(event.target.value)}
        />

        <select
          value={category}
          onChange={(event) => setCategory(event.target.value)}
        >
          {categories.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>
      </div>

      <p>{filteredBooks.length} book(s) found</p>

      {filteredBooks.length > 0 ? (
        <div className="book-grid">
          {filteredBooks.map((book) => (
            <BookCard
              key={book.id}
              book={book}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      ) : (
        <p className="empty-message">
          No books found. Try another search.
        </p>
      )}
    </div>
  );
}

export default BookList;