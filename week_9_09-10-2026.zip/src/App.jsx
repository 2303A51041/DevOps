import { useEffect, useState } from "react";
import {
  BrowserRouter,
  Route,
  Routes,
  useParams
} from "react-router-dom";

import Header from "./components/Header";
import Navigation from "./components/Navigation";
import Footer from "./components/Footer";

import Home from "./pages/Home";
import BookList from "./pages/BookList";
import BookDetails from "./pages/BookDetails";
import Categories from "./pages/Categories";
import Cart from "./pages/Cart";
import Profile from "./pages/Profile";
import NotFound from "./pages/NotFound";

import books from "./data/books";
import "./App.css";

function BookDetailsPage({ onAddToCart, onViewBook }) {
  const { bookId } = useParams();

  useEffect(() => {
    onViewBook(bookId);
  }, [bookId, onViewBook]);

  return <BookDetails onAddToCart={onAddToCart} />;
}

function StoreApp() {
  const [cart, setCart] = useState([]);
  const [recentlyViewed, setRecentlyViewed] = useState([]);

  function handleAddToCart(book) {
    setCart((previousCart) => [...previousCart, book]);
    alert(`${book.title} added to cart!`);
  }

  function handleRemoveFromCart(index) {
    setCart((previousCart) =>
      previousCart.filter((_, itemIndex) => itemIndex !== index)
    );
  }

  function handleViewBook(bookId) {
    const book = books.find((item) => item.id === bookId);

    if (book) {
      setRecentlyViewed((previousBooks) => {
        if (previousBooks[0]?.id === bookId) {
          return previousBooks;
        }

        return [
          book,
          ...previousBooks.filter((item) => item.id !== bookId)
        ];
      });
    }
  }

  return (
    <BrowserRouter>
      <div className="app">
        <Header />
        <Navigation />

        <main className="main-content">
          <Routes>
            <Route
              path="/"
              element={
                <Home
                  onAddToCart={handleAddToCart}
                  recentlyViewed={recentlyViewed}
                />
              }
            />

            <Route
              path="/books"
              element={<BookList onAddToCart={handleAddToCart} />}
            />

            <Route
              path="/books/:bookId"
              element={
                <BookDetailsPage
                  onAddToCart={handleAddToCart}
                  onViewBook={handleViewBook}
                />
              }
            />

            <Route path="/categories" element={<Categories />} />

            <Route
              path="/cart"
              element={
                <Cart
                  cart={cart}
                  onRemoveFromCart={handleRemoveFromCart}
                />
              }
            />

            <Route
              path="/profile"
              element={<Profile recentlyViewed={recentlyViewed} />}
            />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>

        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default StoreApp;