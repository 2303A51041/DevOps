function Summary({ students }) {
  const present = students.filter(
    (student) => student.status === "Present"
  ).length

  const absent = students.filter(
    (student) => student.status === "Absent"
  ).length

  const eligible = students.filter(
    (student) => student.attendance >= 75
  ).length

  return (
    <div>
      <h2>Attendance Summary</h2>
      <p>Total Students: {students.length}</p>
      <p>Present: {present}</p>
      <p>Absent: {absent}</p>
      <p>Eligible: {eligible}</p>
    </div>
  )
}

export default Summary