function StudentCard({ student }) {
  return (
    <div>
      <h2>{student.name}</h2>
      <p>Roll Number: {student.rollNumber}</p>
      <p>Branch: {student.branch}</p>
      <p>Attendance: {student.attendance}%</p>
    </div>
  )
}

export default StudentCard