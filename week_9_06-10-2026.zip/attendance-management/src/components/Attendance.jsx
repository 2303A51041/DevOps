function Attendance({ student, onPresent, onAbsent }) {
  return (
    <div>
      <p>Attendance: {student.attendance}%</p>

      <button onClick={() => onPresent(student.rollNumber)}>
        Present
      </button>

      <button onClick={() => onAbsent(student.rollNumber)}>
        Absent
      </button>
    </div>
  )
}

export default Attendance