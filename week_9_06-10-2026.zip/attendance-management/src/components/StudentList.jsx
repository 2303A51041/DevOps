import StudentCard from "./StudentCard"

function StudentList({ students }) {
  return (
    <div>
      {students.map((student) => (
        <StudentCard
          key={student.rollNumber}
          student={student}
        />
      ))}
    </div>
  )
}

export default StudentList