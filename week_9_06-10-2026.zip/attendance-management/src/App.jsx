import { useState } from "react"
import Header from "./components/Header"
import StudentList from "./components/StudentList"
import Summary from "./components/Summary"

const initialStudents = [
  {
    name: "Rahul",
    rollNumber: "CSE101",
    branch: "CSE",
    attendance: 82,
    status: "Absent"
  },
  {
    name: "Priya",
    rollNumber: "CSE102",
    branch: "CSE",
    attendance: 68,
    status: "Absent"
  },
  {
    name: "Arjun",
    rollNumber: "CSE103",
    branch: "CSE",
    attendance: 91,
    status: "Absent"
  }
]

function App() {
  const [students, setStudents] = useState(initialStudents)

  const markPresent = (rollNumber) => {
    setStudents(
      students.map((student) =>
        student.rollNumber === rollNumber
          ? {
              ...student,
              attendance: Math.min(student.attendance + 1, 100),
              status: "Present"
            }
          : student
      )
    )
  }

  const markAbsent = (rollNumber) => {
    setStudents(
      students.map((student) =>
        student.rollNumber === rollNumber
          ? {
              ...student,
              attendance: Math.max(student.attendance - 1, 0),
              status: "Absent"
            }
          : student
      )
    )
  }

  return (
    <div>
      <Header />

      <StudentList
        students={students}
        onPresent={markPresent}
        onAbsent={markAbsent}
      />

      <Summary students={students} />
    </div>
  )
}

export default App